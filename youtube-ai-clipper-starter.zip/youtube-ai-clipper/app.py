import streamlit as st
import subprocess, tempfile, pathlib, json, zipfile, io, re
import numpy as np

st.set_page_config(page_title='AutoClip Studio', page_icon='🎬', layout='wide')
st.title('🎬 AutoClip Studio')
st.caption('Create vertical highlight clips from videos you own or have permission to edit.')

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-1800:])
    return p.stdout

def duration(path):
    data=json.loads(run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(path)]))
    return float(data['format']['duration'])

def highlights(path, count, seconds):
    dur=duration(path)
    if dur <= seconds: return [(0,max(1,dur))]
    # Analyze audio amplitude across the video. This is a heuristic, not semantic AI.
    raw=path.parent/'audio.raw'
    run(['ffmpeg','-y','-i',str(path),'-vn','-ac','1','-ar','2000','-f','f32le',str(raw)])
    samples=np.fromfile(raw,dtype=np.float32)
    chunk=2000
    levels=np.array([float(np.sqrt(np.mean(x*x))) for x in np.array_split(samples,max(1,len(samples)//chunk)) if len(x)])
    win=max(1,int(seconds))
    candidates=[]
    for start in range(0,max(1,int(dur-seconds)+1),max(2,win//4)):
        part=levels[start:min(len(levels),start+win)]
        if len(part): candidates.append((float(np.mean(part)+.4*np.max(part)),start))
    candidates.sort(reverse=True)
    picks=[]
    for score,start in candidates:
        if all(abs(start-s)>=seconds*.8 for s,_ in picks): picks.append((start,seconds))
        if len(picks)>=count: break
    return sorted(picks)

source=st.radio('Video source', ['Upload a video', 'YouTube URL (may be blocked by hosting)'])
video=st.file_uploader('Upload MP4, MOV or WEBM',type=['mp4','mov','webm']) if source.startswith('Upload') else None
url=st.text_input('YouTube video URL') if source.startswith('YouTube') else ''
allowed=st.checkbox('I own this video or have permission to download and edit it.')
count=st.slider('Number of clips',1,10,5)
seconds=st.slider('Clip length (seconds)',15,60,30,5)
st.info('Highlight selection currently uses audio energy, not AI understanding. Captions and face tracking are not included in this starter.')
if st.button('Generate clips',type='primary'):
    if not allowed: st.error('Please confirm your rights to use the video.')
    elif not video and not url: st.error('Add a video first.')
    elif url and not re.match(r'^https?://(www\.)?(youtube\.com|youtu\.be)/',url): st.error('Enter a valid YouTube URL.')
    else:
        try:
            with st.spinner('Processing video. This may take several minutes...'):
                with tempfile.TemporaryDirectory() as tmp:
                    folder=pathlib.Path(tmp)
                    if video:
                        inp=folder/('source.'+video.name.rsplit('.',1)[-1].lower())
                        inp.write_bytes(video.getvalue())
                    else:
                        import yt_dlp
                        opts={'format':'best[ext=mp4]/best','outtmpl':str(folder/'source.%(ext)s'),'noplaylist':True,'quiet':True,'max_filesize':350*1024*1024}
                        with yt_dlp.YoutubeDL(opts) as ydl: ydl.download([url])
                        files=list(folder.glob('source.*'))
                        if not files: raise RuntimeError('Could not retrieve the video. Try uploading an authorized local copy instead.')
                        inp=files[0]
                    selections=highlights(inp,count,seconds)
                    clips=[]
                    for i,(start,length) in enumerate(selections,1):
                        out=folder/f'clip_{i:02}.mp4'
                        run(['ffmpeg','-y','-ss',str(start),'-i',str(inp),'-t',str(length),'-vf','scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920','-c:v','libx264','-preset','veryfast','-crf','25','-c:a','aac','-movflags','+faststart',str(out)])
                        clips.append((out.name,out.read_bytes(),start))
                    st.success(f'Created {len(clips)} clips')
                    for name,data,start in clips:
                        st.write(f'**{name}** — starts at {start//60:02.0f}:{start%60:02.0f}')
                        st.video(data)
                        st.download_button('Download '+name,data,file_name=name,mime='video/mp4',key=name)
                    mem=io.BytesIO()
                    with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED) as z:
                        for name,data,_ in clips: z.writestr(name,data)
                    st.download_button('Download all clips (ZIP)',mem.getvalue(),file_name='autoclips.zip',mime='application/zip')
        except Exception as exc: st.error(f'Processing failed: {exc}')
