# AutoClip Studio

Streamlit starter for generating vertical highlight clips from videos you have rights to use.

## Deploy

Upload `app.py`, `requirements.txt`, and `packages.txt` to your GitHub repository root. In Streamlit Community Cloud, choose **Create app**, select this repo and branch `main`, and enter `app.py` as the main file path.

## Limitations

- Highlights are selected using loudness, not AI semantic understanding.
- No automatic subtitles or face tracking yet.
- YouTube downloading may be blocked by YouTube or cloud hosting; use the upload option for authorized copies.
- Free hosting may fail on large/long videos due to memory, time or storage limits.
- Processing is temporary; download results before leaving the page.
